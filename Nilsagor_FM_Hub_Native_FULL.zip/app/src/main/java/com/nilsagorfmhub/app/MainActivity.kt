package com.nilsagorfmhub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity: ComponentActivity(){
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContent{ NilsagorFMHub() }
    }
}

@Composable
fun NilsagorFMHub(){
    var tab by remember{mutableStateOf(0)}
    MaterialTheme(colorScheme=darkColorScheme(
        primary=Color(0xFF3F51B5),
        secondary=Color(0xFF19D3FF),
        background=Color(0xFF0B1020),
        surface=Color(0xFF17213A)
    )){
        Scaffold(
            topBar={TopAppBar(title={Text("Nilsagor FM Hub",fontWeight=FontWeight.Bold)})},
            bottomBar={
                NavigationBar{
                    val names=listOf("Home","Radio","Community","Account")
                    val icons=listOf(Icons.Default.Home,Icons.Default.Radio,Icons.Default.People,Icons.Default.Person)
                    names.forEachIndexed{i,n->
                        NavigationBarItem(selected=tab==i,onClick={tab=i},
                            icon={Icon(icons[i],null)},label={Text(n)})
                    }
                }
            }
        ){p->
            Box(Modifier.padding(p).fillMaxSize().background(Color(0xFF0B1020))){
                when(tab){
                    0->Home()
                    1->Radio()
                    2->Community()
                    else->Account()
                }
            }
        }
    }
}

@Composable fun Home(){
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){
        item{
            Card{
                Column(Modifier.padding(20.dp)){
                    Text("সবার জন্য, সব সময়",color=Color(0xFF19D3FF))
                    Text("Nilsagor FM Hub",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
                    Text("Live Radio • Music • News • Community")
                }
            }
        }
        item{Text("Live Now",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
        item{
            Card{
                Row(Modifier.padding(18.dp),verticalAlignment=Alignment.CenterVertically){
                    Icon(Icons.Default.Radio,null,tint=Color(0xFF19D3FF),modifier=Modifier.size(42.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)){
                        Text("Nilsagor Live Radio",fontWeight=FontWeight.Bold)
                        Text("Ready for your stream URL")
                    }
                    Button(onClick={}){Text("LIVE")}
                }
            }
        }
        item{Text("Welcome to Nilsagor FM Hub")}
    }
}

@Composable fun Radio(){
    Column(Modifier.fillMaxSize().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){
        Spacer(Modifier.height(40.dp))
        Icon(Icons.Default.Radio,null,tint=Color(0xFF19D3FF),modifier=Modifier.size(100.dp))
        Text("Nilsagor FM Hub",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Live Radio")
        Spacer(Modifier.height(25.dp))
        Button(onClick={},modifier=Modifier.fillMaxWidth().height(55.dp)){
            Icon(Icons.Default.PlayArrow,null);Spacer(Modifier.width(8.dp));Text("PLAY RADIO")
        }
        Spacer(Modifier.height(18.dp))
        Text("Caster.fm / Icecast / HLS stream will be connected here.")
    }
}

@Composable fun Community(){
    var post by remember{mutableStateOf("")}
    Column(Modifier.fillMaxSize().padding(16.dp)){
        OutlinedTextField(post,{post=it},modifier=Modifier.fillMaxWidth(),label={Text("Write a post")})
        Spacer(Modifier.height(8.dp))
        Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("POST")}
        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth()){
            Column(Modifier.padding(16.dp)){
                Text("Nilsagor FM Hub",fontWeight=FontWeight.Bold)
                Text("Community feed is ready for Firebase connection.")
                Row{TextButton(onClick={}){Text("Like")};TextButton(onClick={}){Text("Comment")};TextButton(onClick={}){Text("Share")}}
            }
        }
    }
}

@Composable fun Account(){
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Account & Settings",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)
        listOf("Profile","Privacy & Security","Notifications","Appearance","Admin Panel").forEach{
            Card(Modifier.fillMaxWidth()){Row(Modifier.padding(18.dp)){Text(it);Spacer(Modifier.weight(1f));Icon(Icons.Default.ChevronRight,null)}}
        }
        OutlinedButton(onClick={},modifier=Modifier.fillMaxWidth()){Text("LOG OUT")}
    }
}

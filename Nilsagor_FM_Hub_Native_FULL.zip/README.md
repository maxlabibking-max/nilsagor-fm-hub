# Nilsagor FM Hub Native Android App

Native Android + Jetpack Compose starter. এটি WebView/iframe app নয়।

## ফোন দিয়ে APK
1. GitHub-এ নতুন repository বানাও।
2. এই ZIP extract করো।
3. project-এর সব files/folders GitHub-এ upload করো।
4. Actions → Build Nilsagor FM Hub APK → Run workflow।
5. Build শেষে Artifacts থেকে APK নামাও।

## Firebase
Package: com.nilsagorfmhub.app
Firebase project: nilsagor-fm-hub-2ac55

পরের ধাপে Firebase Android app registration এবং google-services.json যোগ করা হবে।
